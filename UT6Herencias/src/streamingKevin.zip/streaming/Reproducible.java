package streaming;

public interface Reproducible {

	void reproducir();
	void pausar()	;
	void obtenerTipoContenido();	
	}