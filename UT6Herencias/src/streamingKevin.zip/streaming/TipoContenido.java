package streaming;

public enum TipoContenido {
	MUSICA,
	PELICULA,
	SERIE,
	PODCAST;
}